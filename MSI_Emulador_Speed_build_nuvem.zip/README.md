# MSI Emulador Speed

Projeto Android nativo inicial (Kotlin) para Android 8.0+ e alvo de teste Android 12.

## O que já funciona
- Painel roxo AMOLED de permissões.
- Verificação de sobreposição, acesso ao uso, exclusão de otimização de bateria e escrita de configurações.
- Serviço em primeiro plano com notificação persistente.
- Painel flutuante "Monitor ativo", após conceder sobreposição.
- Botão para parar o serviço.

## Limitação importante
O painel ainda não mede FPS real de jogos. Aplicativos Android comuns não conseguem ler o FPS de outro jogo de forma universal. Também não altera Hz, sensibilidade ou desempenho do sistema sem suporte e permissões específicas do aparelho.

## Compilar
Abra a pasta no Android Studio (versão compatível com Android Gradle Plugin 8.7.3), aguarde a sincronização do Gradle e escolha **Build > Build APK(s)**. O APK de debug será gerado em `app/build/outputs/apk/debug/`.

No Android 13 ou superior, conceda também a permissão de notificações quando o sistema solicitar. O app pede permissões especiais por meio das telas oficiais do Android; o usuário precisa aprová-las manualmente.
