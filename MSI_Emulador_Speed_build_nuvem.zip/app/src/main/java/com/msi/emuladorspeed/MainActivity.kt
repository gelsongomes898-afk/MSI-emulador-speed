package com.msi.emuladorspeed

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshStatus()
    }

    private fun render() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(20))
            setBackgroundColor(0xFF090611.toInt())
        }
        val scroll = ScrollView(this)
        val title = TextView(this).apply {
            text = "MSI EMULADOR SPEED"
            textSize = 25f
            setTextColor(0xFFE9D7FF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "CENTRAL DE PERMISSÕES • ANDROID"
            textSize = 12f
            setTextColor(0xFFB45CFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(22))
        }
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFFE7DDF2.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(0xFF1A1226.toInt())
        }
        page.addView(title)
        page.addView(subtitle)
        page.addView(status)
        addButton(page, "PERMITIR SOBREPOSIÇÃO", "Exibe o painel flutuante.") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        addButton(page, "ACESSO AO USO DOS APLICATIVOS", "Permite consultar qual app está em uso.") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        addButton(page, "IGNORAR OTIMIZAÇÃO DE BATERIA", "Pode ajudar o serviço a continuar ativo.") {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        }
        addButton(page, "MODIFICAR CONFIGURAÇÕES DO SISTEMA", "Necessário apenas para ajustes compatíveis.") {
            if (!Settings.System.canWrite(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            }
        }
        addButton(page, "INICIAR MONITOR EM SEGUNDO PLANO", "Mantém uma notificação e mostra o painel flutuante.") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val i = Intent(this, MonitorService::class.java)
                startForegroundService(i)
            }
        }
        addButton(page, "PARAR MONITOR") {
            stopService(Intent(this, MonitorService::class.java))
        }
        val note = TextView(this).apply {
            text = "Nota: o painel confirma que o serviço está ativo. FPS real de outros jogos não pode ser medido por um app comum sem APIs ou permissões especiais do fabricante."
            textSize = 12f
            setTextColor(0xFFB9AFC5.toInt())
            setPadding(0, dp(18), 0, dp(8))
        }
        page.addView(note)
        scroll.addView(page)
        setContentView(scroll)
        refreshStatus()
    }

    private fun addButton(parent: LinearLayout, label: String, hint: String = "", action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(7), 0, dp(7))
        }
        val b = Button(this).apply {
            text = label
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF7027B8.toInt())
            setOnClickListener { action(); refreshStatus() }
        }
        box.addView(b, LinearLayout.LayoutParams(-1, dp(52)))
        if (hint.isNotEmpty()) {
            val t = TextView(this).apply {
                text = hint
                textSize = 11f
                setTextColor(0xFFB9AFC5.toInt())
                setPadding(dp(4), dp(3), 0, 0)
            }
            box.addView(t)
        }
        parent.addView(box)
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun refreshStatus() {
        if (!::status.isInitialized) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        status.text = buildString {
            appendLine("STATUS DAS PERMISSÕES")
            appendLine("• Sobreposição: ${if (Settings.canDrawOverlays(this@MainActivity)) "LIBERADA" else "PENDENTE"}")
            appendLine("• Acesso ao uso: ${if (hasUsageAccess()) "LIBERADO" else "PENDENTE"}")
            appendLine("• Bateria: ${if (pm.isIgnoringBatteryOptimizations(packageName)) "SEM OTIMIZAÇÃO" else "OTIMIZAÇÃO ATIVA"}")
            append("• Configurações do sistema: ${if (Settings.System.canWrite(this@MainActivity)) "LIBERADAS" else "PENDENTES"}")
        }
    }
}
